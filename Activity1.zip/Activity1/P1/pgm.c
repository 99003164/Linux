#include<stdio.h>
#include<stdlib.h>
#include<sys/wait.h>
#include<unistd.h>
#include<string.h>

int main()
{
	int ret_m, returni_m;
	
	printf("Please Enter the commmand: \n");
	char var[100];
	scanf(" %[^\n]s\n",var);
	ret_m = fork();
	
	if(ret_m <0 ) {
		perror("Fork");
		exit(1);
	}
	
	if(ret_m == 0) { 
	    	execl("/bin/sh", "sh", "-c", var, NULL) ; 
	}
	
	else {
		waitpid(ret_m, &returni_m, 0); 
	}
	exit(0);
}
