#include<unistd.h>
#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<string.h>

int main()
{
	int filedescrpt, no_bytes;
	int wrd=0, ln=0, var;	
	int inwrd=0;
	filedescrpt = open("src.txt", O_RDONLY);
	
	if(filedescrpt < 0) {
		perror("File_Open");
		exit(1);
	}
	
	int maxlength=128;
	char buffer[maxlength];
	no_bytes = read(filedescrpt, buffer, maxlength);
	
	if(no_bytes<0){
		perror("Read_File");
		exit(2);
	}
	
	else {
		var=0;
		while(var!=no_bytes)
		{ 
		 	if(buffer[var] ==' '|| buffer[var] =='\t' ||buffer[var] =='\n' ||buffer[var] =='\0') {
	 			if(inwrd){
		 			inwrd=0;
		 			wrd++;
		 		}
		  		if(buffer[var]=='\n'||buffer[var]=='\0')
		 		ln++;
		 	}
		 	else{
		 		inwrd=1;
		 	}
		 	var++;
		}
	}
	printf("\nword :%d line :%d char:%d\n", wrd, ln, no_bytes);
	close(filedescrpt);
	return 0;	
}
