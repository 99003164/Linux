#include<unistd.h>
#include<stdio.h>
#include<stdlib.h>

int main() {
    int ret_m;
    printf("PID of parent %d\n", getpid());
    ret_m = fork();

    switch(ret_m)
    {
        case 0 : printf("Welcome child process, pid=%d, ppid=%d\n", getpid(), getppid());
                 execl("/usr/bin/gcc", "gcc", "sub.c", "-o", "sl", NULL);
                 execl("./sl","sl",NULL);  
                 break;
        case -1: perror("Fork");
		  exit(1);
        default: printf("Hello parent, pid=%d, ppid=%d\n", getpid(), getppid());
                 break;                 
    }
    return 0;
}
