#include<stdio.h>
int main(){
	int  m=12, n=10, p;
	p = m-n;
	printf("%d", p);
	return 0;
}
