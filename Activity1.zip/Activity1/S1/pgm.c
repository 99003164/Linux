#include<unistd.h>
#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<string.h>

int main()
{
	int filedescrpt, no_bytes;
	int filedescrpt1, no_bytes1;
	
	filedescrpt = open("src.txt", O_RDONLY);
	
	if(filedescrpt < 0) {
		perror("Open_File");
		exit(1);
	}
	
	int maxlength = 128;
	char buffer[maxlength];
	no_bytes = read(filedescrpt, buffer, maxlength);
	
	if(no_bytes < 0){
		perror("Read_File");
		exit(1);
	}
	
	buffer[no_bytes] = '\0';
	filedescrpt1 = open("dest.txt", O_WRONLY | O_CREAT | O_TRUNC, 0666);
	
	if(filedescrpt1 < 0)
	{
		perror("Open_File");
		exit(2);
	}
	
	no_bytes1 = write(filedescrpt1, buffer, no_bytes);
	printf("File is copied successfuly\n");
	close(filedescrpt1);
	close(filedescrpt);
	return 0;
}
