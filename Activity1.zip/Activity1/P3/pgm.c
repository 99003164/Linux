#include<stdio.h>
#include<sys/wait.h>
#include<unistd.h>
#include<stdlib.h>

int main()
{
    int var1,var2,var3;
    int ret_m;
    var1 = fork();

    if(var1==0){
        execl("/usr/bin/gcc", "gcc", "-c", "-Iinc", "src/fact_src.c", "main.c", NULL);
    }
    else if(var1<0){
        perror("Child1 error");
        exit(0);
    }
    else{
        printf("Child1 inside\n");
        waitpid(var1,&ret_m,0);
        var2 = fork();
    }
    if(var2==0){
        execl("/usr/bin/gcc", "gcc", "-Iinc", "fact_src.o", "main.o", "-o", "all.out", NULL);
    }
    else if(var2<0)
    {
        perror("Child2 error");
        exit(1);
    }    
    else{
        printf("Child2 inside\n");
        waitpid(var2, &ret_m, 0);
        var3 = fork();
    }
    if(var3==0){
        execl("all.out", "all.out", NULL);
    }
    else if(var3<0){
        perror("Child3 error");
        exit(3);
    }    
    else{
        waitpid(var3, &ret_m, 0);
    }
    
    return 0;
}
