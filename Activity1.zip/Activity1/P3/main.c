#include "fact_header.h"
#include <stdio.h>

int main(void)
{
	int num = 5;
	printf("Factorial of the given number is %d\n", fact(num));
	return 0;
}
