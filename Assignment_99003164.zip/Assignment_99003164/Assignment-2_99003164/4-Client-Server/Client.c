#include "ServerClient.h"

int main()
{
	int ret, numbytes;
	mqd_t mqid;
	struct mq_attr attr;
	attr.mq_msgsize=256;
	attr.mq_maxmsg=10;
	/* Open a Message Queue in Client Process */
	mqid=mq_open("/mque",O_CREAT | O_RDWR,0666,&attr);
	if(mqid<0)
	{
		perror("mq_open");
		exit(1);
	}

	char str[20] = "Hi I am mehul";
	/* Send a message to Queue */
	ret=mq_send(mqid,str,20,5);
	if(ret<0)
	{
		perror("mq_send");
		exit(2);
	}

	char buffer[8192];
	int maxlen=256,prio;
	/* Receive the message from Server through Queue */
	numbytes=mq_receive(mqid,buffer,maxlen,&prio);
	if(numbytes<0)
	{
		perror("mq_recv");
		exit(2);
	}
	buffer[numbytes]='\0';
	printf("msg from server : %s\n",buffer);
	/* Close the Queue */
	mq_close(mqid);

	return 0;
}

