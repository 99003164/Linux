#include "StackSemaphores.h"

#define MaxItems 5 
/* buffsize set to 5 */
#define buffSize 5

sem_t emp;
sem_t full;
int input= 0;
int output= 0;
int item = 0;
int buff[buffSize];

void *producer(void *pno) {
  if (input== buffSize - 1) {
    printf("Producer Stack is full \n");
  } 
  else {
    for (int i = 0; i < MaxItems; i++) {
      item = rand();
      sem_wait(&emp);
      /* put value item into the buff */
      buff[input] = item;
      printf("Producer %d: Insert Item %d at %d\n", *((int *)pno), buff[input],
             input);
      input= (input+ 1) % buffSize;
      sem_post(&full);
    }
  }
}

void *consumer(void *cno) {
  if (output== buffSize - 1) {
    printf("Consumer Stack is full\n");
  } 
  else {
    int item = 0;
    for (int i = 0; i < MaxItems; i++) {
      sem_wait(&full);
      /* take one unit of data from the buff */
      item = buff[output];
      printf("Consumer %d: Remove Item %d from %d\n", *((int *)cno), item, output);
      output= (output+ 1) % buffSize;
      sem_post(&emp);
    }
  }
}

void main() {
  pthread_t pro[5], con[5];
  sem_init(&emp, 0, buffSize);
  sem_init(&full, 0, 0);

  int a[5] = {1, 2, 3, 4, 5}; 

  for (int i = 0; i < 5; i++) {
    pthread_create(&pro[i], NULL, (void *)producer, (void *)&a[i]);
  }
  for (int i = 0; i < 5; i++) {
    pthread_create(&con[i], NULL, (void *)consumer, (void *)&a[i]);
  }

  for (int i = 0; i < 5; i++) {
    pthread_join(pro[i], NULL);
  }
  for (int i = 0; i < 5; i++) {
    pthread_join(con[i], NULL);
  }

  sem_destroy(&emp);
  sem_destroy(&full);
}
