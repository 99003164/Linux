#ifndef __STACKSEMAPHORES_H
#define __STACKSEMAPHORES_H

#include <pthread.h>
#include <semaphore.h>
#include <stdlib.h>
#include <stdio.h>

void StackSemaphores();

#endif