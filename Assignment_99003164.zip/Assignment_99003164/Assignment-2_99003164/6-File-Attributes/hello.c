#include<stdio.h>

#define PI 22.0/7.0
#define SQUARE(x) (x) * (x)

int main() {
  printf("Hello World\n");   /*some comment */
  printf("Thank You\n");
  
  return 0;
}
