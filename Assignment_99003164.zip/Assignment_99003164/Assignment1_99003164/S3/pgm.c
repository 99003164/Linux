#include <stdlib.h> 
#include <sys/types.h> 
#include <signal.h> 
#include <stdio.h> 
#include <unistd.h> 
  
void sighup();  // functions declaration 
void sigint(); 
void sigquit(); 
  
void main() { 
    int pid;  
    
    if ((pid = fork()) < 0) {  	/* child process */
        perror("fork"); 
        exit(1); 
    } 
  
    if (pid == 0) { 			/* child process*/
        signal(SIGHUP, sighup); 
        signal(SIGINT, sigint); 
        signal(SIGQUIT, sigquit); 
        for (;;) 			/* infinite loop */
            ; 
    } 
  
    else{ 				/* parent process */
        printf("\nPARENT: Sending SIGHUP\n"); 
        kill(pid, SIGHUP); 
  	sleep(5);
        
        printf("\nPARENT: Sending SIGINT\n"); 
        kill(pid, SIGINT); 
  	sleep(5);
        
        printf("\nPARENT: Sending SIGQUIT\n"); 
        kill(pid, SIGQUIT); 
        sleep(5); 
    } 
} 
  
// function definition of sighup()
void sighup(){ 
    signal(SIGHUP, sighup); 		/* signal reset */
    printf("CHILD: Received a SIGHUP\n"); 
} 
  
// function definition of sigint()  
void sigint() { 
    signal(SIGINT, sigint); 		/* signal reset */
    printf("CHILD: Received a SIGINT\n"); 
} 
  
// function definition  sigquit() 
void sigquit() { 
    printf("Parent killed child process!!!\n"); 
    exit(0); 
} 
