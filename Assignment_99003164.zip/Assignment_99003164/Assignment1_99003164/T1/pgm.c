#include<pthread.h> 
#include<stdio.h>

#define MAXIMUM 1000 
#define MAXIMUM_THREAD 10 

int result[10] = { 0 }; 
int p = 0; 
int arr[MAXIMUM];

void* array_result(void* arg) {  
	int p_thread = p++; 
        for(int m = p_thread * (MAXIMUM / 10); m < (p_thread + 1) * (MAXIMUM / 10); m++) {
		arr[m]=5;
	}
        // Each thread computes result of 1/10th of array 
  
        for (int m = p_thread * (MAXIMUM / 10); m < (p_thread + 1) * (MAXIMUM / 10); m++) 
        	result[p_thread] += arr[m];
} 
  
int main() 
{ 
    pthread_t threads[MAXIMUM_THREAD]; 
  
    for (int m = 0; m < MAXIMUM_THREAD; m++) 	 // Creating 10 threads 
        pthread_create(&threads[m], NULL, array_result, (void*)NULL); 
  
    for (int m = 0; m < MAXIMUM_THREAD; m++) 	// joining 10 threads i.e. waiting for all 10 threads to complete 
        pthread_join(threads[m], NULL); 
  
    int total_result = 0; 			   // adding result of all 10 ps 
    for (int m = 0; m < MAXIMUM_THREAD; m++) 
        total_result += result[m]; 
  
    printf("total sum: %d\n",total_result);
  
    return 0; 
} 
