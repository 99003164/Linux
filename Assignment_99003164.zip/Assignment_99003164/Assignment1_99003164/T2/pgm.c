#include <pthread.h> 
#include <stdio.h> 
#include <stdlib.h> 
  
#define Th_maxi 4 	// maximum no of thread 
#define maxi 16 	// Array size
  
int maxi_number[Th_maxi] = { 0 }; 
int th_no = 0; 
int a[maxi] = { 1, 5, 7, 10, 12, 14, 15, 18, 20, 22, 25, 27, 300, 64, 110, 220 }; 
          
void maximumfun(void* arg) 	// Find maximum element
{ 
    int m, number = th_no++; 
    int maxis = 0; 
  
    for (m = number * (maxi / 4); m < (number + 1) * (maxi / 4); m++) { 
        if (a[m] > maxis) 
            maxis = a[m]; 
    } 
    maxi_number[number] = maxis; 
} 
  
int main() { 
    int maxis = 0; 
    int m; 
    pthread_t threads[Th_maxi]; 
  
    for (m = 0; m < Th_maxi; m++) 		// to create 4 threads 
        pthread_create(&threads[m], NULL, maximumfun, (void*)NULL);                     
  
    for (m = 0; m < Th_maxi; m++) 		// waiting for all 4 threads to complete i.e., joining 4 threads  
        pthread_join(threads[m], NULL); 
  
    for (m = 0; m < Th_maxi; m++) { 		 // Finding maximum element by individual threads in an array 
        if (maxi_number[m] > maxis) 
            maxis = maxi_number[m]; 
    } 
    printf("maximum element in an array is : %d\n", maxis); 
  
    return 0; 
}
