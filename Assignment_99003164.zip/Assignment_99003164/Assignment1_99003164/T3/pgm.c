#include <time.h>
#include <stdio.h>
 
int main()
{
    time_t Time= time(NULL);
    struct  tm tim = *localtime(&Time);
     
    printf("Date: %02d/%02d/%04d\n",tim.tm_mday, tim.tm_mon+1, tim.tm_year+1900);
    printf("Time: %02d:%02d:%02d\n",tim.tm_hour, tim.tm_min, tim.tm_sec);
 
    return 0;
}
