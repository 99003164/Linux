/**
* @file fact_header.h
*
*/
#ifndef __FACT_HEADER_H__
#define __FACT_HEADER_H__

/**
* Calculates the factorial of integer number
* @param[in] number for which factorial has to be found
* @return Factorial of the number
* @note Returns -1 for negative values
*/
int fact(int num);

#endif /* #ifndef __FACT_HEADER_H__ */
