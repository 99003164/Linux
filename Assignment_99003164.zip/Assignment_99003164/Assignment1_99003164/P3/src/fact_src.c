#include "fact_header.h"

int fact(int num)
{
  if(num < 0)
    return -1;   // Return -1 for negative numbers  

  if(num == 0)
    return 1;   // Return 1 for value 0

  return num * fact(num-1); // Recursively calculate factorial of the given number 
}
